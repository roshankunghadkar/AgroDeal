package com.app.dao;

import com.app.pojos.Request;

public interface IRequestDao {
	
	String sendRequest(int pid,int rid);
	

}
